﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IEnumerableApp.Model;

namespace IEnumerableApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Employee e1 = new Employee { Id = 104, Name = "Sam", Salary = 60000, Department = "Sales" };
            //Employee e2 = new Employee { Id = 105, Name = "Marlie", Salary = 80000, Department = "IT" };
            //Employee e3 = new Employee { Id = 106, Name = "Ciri", Salary = 70000, Department = "IT" };
            AurionProDBContext db = new AurionProDBContext();
            //db.Employees.Add(e1);
            //db.Employees.Add(e2);
            //db.Employees.Add(e3);
            IEnumerable<Employee> list = db.Employees.Where(d => d.Department.Equals("IT"));
            Console.WriteLine("Employees in IT Dept are:");
            foreach (var emp in list)
            {
                Console.WriteLine(emp.Name);
            }
            db.SaveChanges();
        }
    }
}
