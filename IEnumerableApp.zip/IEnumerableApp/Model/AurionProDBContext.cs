﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IEnumerableApp.Model
{
    class AurionProDBContext:DbContext
    {
        public AurionProDBContext() : base("AurionProDB") { }
        public DbSet<Employee> Employees { get; set; }
    }
}
